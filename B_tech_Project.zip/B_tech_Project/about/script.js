document.addEventListener('DOMContentLoaded', function() {
    const learnMoreButton = document.getElementById('learnMore');

    learnMoreButton.addEventListener('click', function() {
        alert('Thank you for your interest! More information will be available soon.');
    });
});